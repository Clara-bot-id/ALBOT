
const help = (prefix) => { 
	return `
┏━━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━━┓
┃╔═══════════════════╗
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}info*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}sticker*
┃╠➥ *${prefix}sticker nobg*
┃╠➥ *${prefix}tsticker*
┃╠➥ *${prefix}nulis*
┃╠➥ *${prefix}logowolf*
┃╠➥ *${prefix}logowolf2*
┃╠➥ *${prefix}neonimg*
┃╠➥ *${prefix}3dimg*
┃╠➥ *${prefix}blackpink*
┃╠➥ *${prefix}phmaker*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tts*
┃╠➥ *${prefix}kodetts*
┃╠➥ *${prefix}tiktok*
┃╠➥ *${prefix}meme*
┃╠➥ *${prefix}memeindo*
┃╠➥ *${prefix}nsfwloli* 
┃╠➥ *${prefix}ocr*
┃╠➥ *${prefix}wallpaper*
┃╠➥ *${prefix}neko*
┃╠➥ *${prefix}randomanime*
┃╠➥ *${prefix}loli*
┃╠➥ *${prefix}waifu*
┃╠➥ *${prefix}waifu2*
┃╠➥ *${prefix}waibu*
┃╠➥ *${prefix}qrcode*
┃╠➥ *${prefix}randomhen*
┃╠➥ *${prefix}nekonsfw*
┃╚═══════════════════╝
┣━━━°❀ ❬ 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ❭ ❀°━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytmp3*
┃╠➥ *${prefix}fb*
┃╠➥ *${prefix}ytmp4*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}add* [62xxx]
┃╠➥ *${prefix}kick* [tag]
┃╠➥ *${prefix}setpp*
┃╠➥ *${prefix}tagme*
┃╠➥ *${prefix}demote* [tag]
┃╠➥ *${prefix}promote* [tag]
┃╠➥ *${prefix}grup* [open/close]
┃╠➥ *${prefix}welcome* [enable/disable]
┃╠➥ *${prefix}nsfw* [enable/disable]
┃╠➥ *${prefix}simih* [enable/disable]
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}bc* 
┃╠➥ *${prefix}clearall*
┃╠➥ *${prefix}setprefix*
┃╠➥ *${prefix}leave*
┃╠➥ *${prefix}clone* [tag]
┃╚═══════════════════╝
┣━━━━━°❀ ❬ 𝙎𝙋𝘼𝙈 ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}spamsms*
┃╠➥ *${prefix}spamcall*
┃╠➥ *${prefix}spamgmail*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytsearch*
┃╠➥ *${prefix}listadmin*
┃╠➥ *${prefix}blocklist*
┃╠➥ *${prefix}wait*
┃╠➥ *${prefix}nama*
┃╠➥ *${prefix}map*
┃╠➥ *${prefix}tiktokstalk*
┃╠➥ *${prefix}igstalk*
┃╠➥ *${prefix}shortlink*
┃╠➥ *${prefix}url2img*
┃╠➥ *${prefix}alay*
┃╠➥ *${prefix}quotes*
┃╠➥ *${prefix}hilih*
┃╠➥ *${prefix}bucin*
┃╠➥ *${prefix}wiki*
┃╠➥ *${prefix}wikien*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙎𝙊𝙐𝙉𝘿 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}yameteh*
┃╚═══════════════════╝
┗━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.help = help

 